from django.urls import re_path, include, path
# from rest_framework.routers import DefaultRouter
from django.urls import path
from accounts import views, admin
from django.conf.urls import url

# ROUTER = DefaultRouter(trailing_slash=False)

urlpatterns = [
        # url(r'^', include(ROUTER.urls)),
        path('app/register/', views.register, name='register'),
        path('identification_card/', views.identification_card, name='identification_card'),
        path('add_item/', views.add_item, name='add_item'),
        path('identification_card/<str:id>', views.identification_card_id, name='identification_card_id'),
        path('app/logout/', views.logout_view, name='logout'),
        path('app/login/', views.login_view, name='login'),
        path('home/', views.home, name='home'),
        path('item-list', views.item_list, name='item_list'),
        path('user-details', views.user_details, name='user_details'),
        path('user/<int:id>', views.user_data, name='user_data'),
        path('reset_password', views.reset_password, name='reset_password'),
        path('export_page', views.export_page, name='export_page'),
        path('upload_xlsx', views.upload_xlsx, name='upload_xlsx'),
        path('import_page', views.import_page, name='import_page'),
        path('error', views.error, name='error'),
        path('prefix', views.prefix, name='prefix'),
        path('item_not_found', views.item_not_found, name='item_not_found'),
    ]
