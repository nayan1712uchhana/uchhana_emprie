from django.db import migrations
from django.db import transaction
from accounts.models import User


class Migration(migrations.Migration):

    dependencies = [
        ("accounts", "0001_initial"),
    ]

    def create_super_user(apps, schema_editor):
        with transaction.atomic():
            User.objects.create(first_name="Super", last_name="User", email="asshutoshsharma@gmail.com", password="ashutosh674", is_superuser=True)


    operations = [
        migrations.RunPython(create_super_user),
    ]
