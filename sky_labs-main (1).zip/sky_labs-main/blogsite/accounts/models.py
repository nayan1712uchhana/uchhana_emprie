import random
from typing import List, Tuple

from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.utils.translation import gettext as _
from django.contrib.auth.base_user import BaseUserManager
import qrcode
from PIL import Image, ImageDraw
from io import BytesIO
from django.core.files import File

TYPE_CHOICES: List[Tuple[str, str]] = [
    ('rudraksha', _('Rudraksha')),
    ('crystal', _('Crystal')),
    ('wood', _('Wood')),
]


class UserManager(BaseUserManager):
    """
    Custom User Manager to handle creating our Users
    """
    use_in_migrations = True

    def _create_user(self, email, first_name, last_name, password, **extra_fields):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError('Email is required')

        email = self.normalize_email(email)
        user = self.model(email=email, first_name=first_name, last_name=last_name, **extra_fields)
        if password is None:
            user.set_unusable_password()
        else:
            user.set_password(password)
        user.full_clean()
        user.save(using=self._db)
        return user

    def create_user(self, email, first_name, last_name, password=None, **extra_fields):
        """
        Public facing create user function. Uses Email and Password to create a user.
        """
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, first_name, last_name, password, **extra_fields)


class IdentificationRecord(models.Model):
    id = models.AutoField(primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True, editable=False, null=True, help_text=_("Created At"))
    updated_at = models.DateTimeField(auto_now=True, null=True, help_text=_("Updated At"))
    unique_number = models.IntegerField(unique=True, null=False, blank=False,
                                     help_text=_("Unique Number of Record"))
    type = models.TextField(choices=TYPE_CHOICES, blank=False, default="rudraksha",
                            help_text=_("Type"))
    url = models.URLField()
    image = models.ImageField(upload_to='item_qrcode', blank=True)
    item_image = models.ImageField(upload_to='item', blank=True)
    color = models.CharField(max_length=150, null=True, blank=True, help_text=_("Color of the Item"))
    cut_and_shape = models.CharField(max_length=150, null=True, blank=True, help_text=_("Cut & Shape of the Item"))
    mounting_stats = models.CharField(max_length=150, null=True, blank=True, help_text=_("Mounting Stats of the Item"))
    dimension = models.CharField(max_length=150, null=True, blank=True, help_text=_("Dimension of the Item"))
    micro_obs = models.CharField(max_length=150, null=True, blank=True, help_text=_("Micro Observation of the Item"))
    natural_faces = models.CharField(max_length=150, null=True, blank=True, help_text=_("Natural Faces of the Item"))
    remark = models.CharField(max_length=150, null=True, blank=True, help_text=_("Remark of the Item"))
    indian_name = models.CharField(max_length=150, null=True, blank=True, help_text=_("Indian Name of the Item"))
    weight = models.CharField(max_length=150, null=True, blank=True, help_text=_("Weight of the Item"))
    org = models.CharField(max_length=150, null=True, blank=True, help_text=_("On Behalf of of the Item"))
    refractive_index = models.CharField(max_length=150, null=True, blank=True, help_text=_("Refractive Index"))
    specific_gravity = models.CharField(max_length=150, null=True, blank=True, help_text=_("Specific Gravity"))
    hardness = models.CharField(max_length=150, null=True, blank=True, help_text=_("Hardness"))
    species = models.CharField(max_length=150, null=True, blank=True, help_text=_("Species"))
    variety = models.CharField(max_length=150, null=True, blank=True, help_text=_("Variety"))
    origin = models.CharField(max_length=150, null=True, blank=True, help_text=_("Origin"))
    odour = models.CharField(max_length=150, null=True, blank=True, help_text=_("Odour"))

    def save(self, *args, **kwargs):
        qrcode_img = qrcode.make(self.url)
        canvas = Image.new("RGB", (400, 400), "white")
        draw = ImageDraw.Draw(canvas)
        canvas.paste(qrcode_img)
        buffer = BytesIO()
        canvas.save(buffer, "PNG")
        self.image.save(f'image{str(self.unique_number)}', File(buffer), save=False)
        # self.item_image.save(f'image{random.randint(0, 9999)}', File(self.item_image), save=False)
        # self.item_image.save()
        canvas.close()
        super().save(*args, **kwargs)


class ItemPrefix(models.Model):
    id = models.AutoField(primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True, editable=False, null=True, help_text=_("Created At"))
    updated_at = models.DateTimeField(auto_now=True, null=True, help_text=_("Updated At"))
    unique_number_prefix = models.IntegerField(unique=True, null=False, blank=False,
                                        help_text=_("Unique Number of Record"))
    type = models.TextField(choices=TYPE_CHOICES, blank=False, default="rudraksha",
                            help_text=_("Type"))


class User(AbstractBaseUser):
    # id = models.UUIDField(default=uuid_model.uuid4, primary_key=True, editable=False, help_text=_("Id"))
    created_at = models.DateTimeField(auto_now_add=True, editable=False, null=True, help_text=_("Created At"))
    updated_at = models.DateTimeField(auto_now=True, null=True, help_text=_("Updated At"))
    first_name = models.CharField(max_length=150, help_text=_("First Name of the User"))
    last_name = models.CharField(max_length=150, help_text=_("Last Name of the User"))
    email = models.EmailField(unique=True, help_text=_("Email of the user"))
    is_active = models.BooleanField(null=False, default=True, db_index=True,
                                    help_text=_('Indicate a user is active or inactive.'))
    phone = models.PositiveIntegerField(blank=True, null=True, help_text=_("Phone Number"))
    is_superuser = models.BooleanField(null=False, default=False, help_text=_("Is Superuser or not"))

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    @property
    def is_staff(self):
        return True

    def has_module_perms(self, app_label):
        return True

    def has_perm(self, perm, object=None):
        return True
