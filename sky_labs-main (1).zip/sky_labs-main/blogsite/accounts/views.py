import io
import os
import sys
from email.mime.image import MIMEImage

from django.contrib import auth
from django.contrib import messages
from django.shortcuts import redirect, render, get_object_or_404
from accounts.models import User, IdentificationRecord, ItemPrefix
from blogsite.settings import BASE_URL
from django.core.mail import send_mail, EmailMessage
from django.http import HttpResponse
import openpyxl
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import Alignment
import xlrd
from PIL import Image
from django.core.files.uploadedfile import InMemoryUploadedFile


def register(request):
    """ For create login users """
    if request.method == 'POST':
        try:
            user = User.objects.create(first_name=request.POST.get('first_name'),
                                       last_name=request.POST.get('last_name'),
                                       email=request.POST.get('email'),
                                       phone=request.POST.get('phone'),
                                       password=request.POST.get('password'))
            auth.login(request, user)
            messages.success(request, 'Register Successfully')
            return redirect('index')
        except Exception as e:
            print(str(e))
            messages.error(request, str(e))
    return render(request, 'registration.html')


def send_record_mail(request, data):
    body = "Hi %s,\n\nPlease find the details of the items below.\n\nDetails:-\n\n1. Unique Number : %s\n" \
           "2.Color : %s\n3. Cut & Shape : %s\n4. Mounting Stats : %s\n" \
           "5. Dimension : %s\n6. Micro Observation : %s\n7. Natural Faces : %s\n8. Remark : %s\n" \
           "9. Indian Name : %s\n10. Weight : %s\n11. On Behalf Of : %s\n\n\nThanks" \
           % (request.user.first_name, str(data.unique_number), data.color, data.cut_and_shape, data.mounting_stats,
              data.dimension,
              data.micro_obs, data.natural_faces, data.remark, data.indian_name, data.weight, data.org)
    mail = EmailMessage("New record added - %s" % str(data.unique_number), body, ['info@jupiterspeaks.com'],
                        [request.user.email])
    fp = open('media/' + os.path.join(data.image.name), 'rb')
    msg_img = MIMEImage(fp.read())
    fp.close()
    msg_img.add_header('Content-ID', '<{}>'.format(data.image.name))
    mail.attach(msg_img)
    if data.item_image.name:
        fpt = open('media/' + os.path.join(data.item_image.name), 'rb')
        item_img = MIMEImage(fpt.read())
        fpt.close()
        item_img.add_header('Content-ID', '<{}>'.format(data.item_image.name))
        mail.attach(item_img)
    mail.send(fail_silently=False)


def add_item(request, *args, **kwargs):
    """ For create login users """
    if request.user.is_authenticated:
        if request.method == 'POST':
            try:
                item_prefix_data = ItemPrefix.objects.filter(type=request.POST.get('type'))
                unique_number = ((item_prefix_data.first().unique_number_prefix if item_prefix_data else 10000) + \
                                 IdentificationRecord.objects.filter(type=request.POST.get('type')).count()) \
                    if request.POST.get('type') else \
                    IdentificationRecord.objects.filter(type=request.POST.get('type')).count() + 10000
                data = IdentificationRecord.objects.create(unique_number=unique_number,
                                                           item_image=request.FILES.get('img'),
                                                           color=request.POST.get('color') or None,
                                                           cut_and_shape=request.POST.get('cut_and_shape') or None,
                                                           mounting_stats=request.POST.get('mounting_stats') or None,
                                                           dimension=request.POST.get('dimension') or None,
                                                           micro_obs=request.POST.get('micro_obs') or None,
                                                           natural_faces=request.POST.get('natural_faces') or None,
                                                           remark=request.POST.get('remark') or None,
                                                           indian_name=request.POST.get('indian_name') or None,
                                                           weight=request.POST.get('weight') or None,
                                                           org=request.POST.get('org') or None,
                                                           refractive_index=request.POST.get(
                                                               'refractive_index') or None,
                                                           specific_gravity=request.POST.get(
                                                               'specific_gravity') or None,
                                                           hardness=request.POST.get('hardness') or None,
                                                           species=request.POST.get('species') or None,
                                                           variety=request.POST.get('variety') or None,
                                                           origin=request.POST.get('origin') or None,
                                                           odour=request.POST.get('odour') or None,
                                                           type=request.POST.get('type') or None,
                                                           url=BASE_URL + '/identification_card/%s' % unique_number)
                messages.success(request, 'Added Successfully')
                send_record_mail(request, data)
                return render(request, 'item_details.html', context={'data': data})
            except Exception as e:
                print(str(e))
                messages.error(request, str(e))
        return render(request, 'item_data_entry.html')
    else:
        return redirect('error')


def identification_card(request, *args, **kwargs):
    """ For create login users """
    if request.method == 'GET' and request.GET.get('unique_number'):
        data = IdentificationRecord.objects.filter(unique_number=request.GET.get('unique_number'))
        if data.exists():
            return render(request, 'item_details.html', context={'data': data.first()})
    return redirect('item_not_found')


def identification_card_id(request, *args, **kwargs):
    """ For create login users """
    if request.method == 'GET' and kwargs.get('id'):
        data = IdentificationRecord.objects.filter(unique_number=kwargs.get('id'))
        if data.exists():
            return render(request, 'item_details.html', context={'data': data.first()})
    return redirect('index')


def reset_password(request):
    if request.method == 'POST':
        try:
            request.user.password = request.POST.get('password')
            request.user.save()
            messages.success(request, 'Reset Successfully')
            return render(request, 'user_details.html', context={'data': request.user})
        except Exception as e:
            print(str(e))
            messages.error(request, str(e))
        return render(request, 'user_details.html', context={'data': request.user})
    else:
        return redirect('index')


def user_details(request):
    if request.user.is_authenticated:
        return render(request, 'user_details.html', context={'data': request.user,
                                                             'users': User.objects.all(),
                                                             'request_user': request.user})
    else:
        return redirect('error')


def user_data(request, *args, **kwargs):
    user_id = kwargs.get('id')
    if request.user.is_superuser:
        if request.POST.get('is_superuser'):
            try:
                user = User.objects.get(id=request.POST.get('id'))
                user.is_superuser = True
                user.save()
                return render(request, 'user_details.html', context={'data': user,
                                                                     'users': User.objects.all(),
                                                                     'request_user': request.user})
            except Exception as e:
                print(str(e))
                messages.error(request, str(e))
        else:
            return render(request, 'user_details.html', context={'data': User.objects.get(id=user_id),
                                                                 'users': User.objects.all(),
                                                                 'request_user': request.user})
    else:
        return redirect('error')


def item_list(request):
    if request.user.is_authenticated:
        data = IdentificationRecord.objects.all()
        return render(request, 'item_list.html', context={'data': data})
    else:
        return redirect('error')


def logout_view(request):
    auth.logout(request)
    return redirect('index')


def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = User.objects.filter(email=username, password=password)
        if user.exists():
            auth.login(request, user.first())
        else:
            messages.error(request, "Wrong Credentials")
            return render(request, 'registration.html')
        return redirect('index')
    else:
        return redirect('register')


def home(request):
    """ For home page"""
    return render(request, 'home.html')

def item_not_found(request):
    """ For home page"""
    return render(request, 'item_not_found.html')


def prefix(request):
    """ For home page"""
    if request.user.is_authenticated:
        if request.method == 'POST':
            type_data = request.POST.get('type')
            unique_number_prefix = request.POST.get('unique_number_prefix')
            item_exist = ItemPrefix.objects.filter(type=type_data)
            try:
                if item_exist.exists():
                    data = item_exist.first()
                    data.unique_number_prefix = unique_number_prefix
                    data.save()
                else:
                    ItemPrefix.objects.create(type=type_data, unique_number_prefix=unique_number_prefix)
            except Exception as e:
                print(str(e))
                messages.error(request, str(e))
            return render(request, 'unique_number_prefix.html', context={'data': ItemPrefix.objects.all()})
        return render(request, 'unique_number_prefix.html', context={'data': ItemPrefix.objects.all()})
    else:
        return redirect('error')


def error(request):
    """ For home page"""
    return render(request, 'not_allowed.html')


def upload_xlsx(request):
    if request.user.is_authenticated:
        return render(request, 'upload_xlsx.html')
    else:
        return redirect('error')


def import_page(request):
    try:
        if request.user.is_authenticated:
            xlxs_file = request.FILES.get('xlsx_file')
            data = xlxs_file.read()
            with xlrd.open_workbook(file_contents=data) as f:
                worksheet = f.sheet_by_index(0)
                row_count = worksheet.nrows
                column_count = worksheet.ncols
                for i in range(1, row_count):
                    dict = {}
                    for j in range(0, column_count):
                        if worksheet.cell(0, j).value == 'item_image':
                            im = Image.open(worksheet.cell(i, j).value)
                            output = io.BytesIO()
                            im = im.resize((300, 300))
                            im.save(output, format='png', quality=90)
                            output.seek(0)
                            profile_pic = InMemoryUploadedFile(output, 'ImageField',
                                                               "%s.png" % 'demo',
                                                               'image/png',
                                                               sys.getsizeof(output), None)
                            dict.update({worksheet.cell(0, j).value: profile_pic})
                        elif worksheet.cell(0, j).value == 'type':
                            type_data = worksheet.cell(i, j).value
                        else:
                            dict.update({worksheet.cell(0, j).value: worksheet.cell(i, j).value})
                    item_prefix_data = ItemPrefix.objects.filter(type=type_data)
                    dict.update(
                        {'unique_number': ((item_prefix_data.first().unique_number_prefix if item_prefix_data else 10000) + \
                                           IdentificationRecord.objects.filter(type=type_data).count()) if type_data else
                        IdentificationRecord.objects.filter(type=type_data).count() + 10000})
                    newrecord = IdentificationRecord.objects.create(**dict)
                    newrecord.save()
                    messages.success(request, 'Added Successfully')
                    send_record_mail(request, newrecord)
            return redirect('item_list')
        else:
            return redirect('error')
    except Exception as e:
        print(str(e))
        messages.error(request, str(e))


def export_page(request):
    try:
        if request.user.is_authenticated:
            type_data = request.POST.get('type')
            unique_number_from = request.POST.get('unique_number_from')
            unique_number_to = request.POST.get('unique_number_to')
            data = IdentificationRecord.objects.filter(unique_number__gte=unique_number_from,
                                                       unique_number__lte=unique_number_to)
            if type_data != 'all':
                data = data.filter(type=type_data)
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            sheet.title = str("Certificate Record List")
            sheet['A1'] = "certificate_number"
            sheet['B1'] = "type"
            sheet['C1'] = "color"
            sheet['D1'] = "cut_and_shape"
            sheet['E1'] = "mounting_stats"
            sheet['F1'] = "dimensions"
            sheet['G1'] = "micro_obs"
            sheet['H1'] = "indian_name"
            sheet['I1'] = "weight"
            sheet['J1'] = "species"
            if type_data == 'rudraksha':
                sheet['K1'] = "origin"
                sheet['L1'] = "natural_faces"
                sheet['M1'] = "org"
                sheet['N1'] = "remark"
            elif type_data == 'wood':
                sheet['K1'] = "odour"
                sheet['L1'] = "origin"
                sheet['M1'] = "org"
                sheet['N1'] = "remark"
            elif type_data == 'crystal':
                sheet['K1'] = "refractive_index"
                sheet['L1'] = "specific_gravity"
                sheet['M1'] = "hardness"
                sheet['N1'] = "variety"
                sheet['O1'] = "org"
                sheet['P1'] = "remark"
            else:
                sheet['K1'] = "origin"
                sheet['L1'] = "natural_faces"
                sheet['M1'] = "odour"
                sheet['N1'] = "refractive_index"
                sheet['O1'] = "specific_gravity"
                sheet['P1'] = "hardness"
                sheet['Q1'] = "variety"
                sheet['R1'] = "org"
                sheet['S1'] = "remark"
            for v, d in enumerate(data):
                sheet.cell((v + 2), 1, d.unique_number or 'None')
                sheet.cell((v + 2), 1).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 2, d.type or 'None')
                sheet.cell((v + 2), 2).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 3, d.color or 'None')
                sheet.cell((v + 2), 3).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 4, d.cut_and_shape or 'None')
                sheet.cell((v + 2), 4).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 5, d.mounting_stats or 'None')
                sheet.cell((v + 2), 5).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 6, d.dimension or 'None')
                sheet.cell((v + 2), 6).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 7, d.micro_obs or 'None')
                sheet.cell((v + 2), 7).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 8, d.indian_name or 'None')
                sheet.cell((v + 2), 8).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 9, d.weight or 'None')
                sheet.cell((v + 2), 9).alignment = Alignment(wrap_text=True, vertical="center")
                sheet.cell((v + 2), 10, d.species or 'None')
                sheet.cell((v + 2), 10).alignment = Alignment(wrap_text=True, vertical="center")
                if type_data == 'rudraksha':
                    sheet.cell((v + 2), 11, d.origin or 'None')
                    sheet.cell((v + 2), 11).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 12, d.natural_faces or 'None')
                    sheet.cell((v + 2), 12).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 13, d.org or 'None')
                    sheet.cell((v + 2), 13).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 14, d.remark or 'None')
                    sheet.cell((v + 2), 14).alignment = Alignment(wrap_text=True, vertical="center")
                elif type_data == 'wood':
                    sheet.cell((v + 2), 11, d.odour or 'None')
                    sheet.cell((v + 2), 11).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 12, d.origin or 'None')
                    sheet.cell((v + 2), 12).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 13, d.org or 'None')
                    sheet.cell((v + 2), 13).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 14, d.remark or 'None')
                    sheet.cell((v + 2), 14).alignment = Alignment(wrap_text=True, vertical="center")
                elif type_data == 'crystal':
                    sheet.cell((v + 2), 11, d.refractive_index or 'None')
                    sheet.cell((v + 2), 11).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 12, d.specific_gravity or 'None')
                    sheet.cell((v + 2), 12).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 13, d.hardness or 'None')
                    sheet.cell((v + 2), 13).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 14, d.variety or 'None')
                    sheet.cell((v + 2), 14).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 15, d.org or 'None')
                    sheet.cell((v + 2), 15).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 16, d.remark or 'None')
                    sheet.cell((v + 2), 16).alignment = Alignment(wrap_text=True, vertical="center")
                else:
                    sheet.cell((v + 2), 11, d.origin or 'None')
                    sheet.cell((v + 2), 11).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 12, d.natural_faces or 'None')
                    sheet.cell((v + 2), 12).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 13, d.odour or 'None')
                    sheet.cell((v + 2), 13).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 14, d.refractive_index or 'None')
                    sheet.cell((v + 2), 14).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 15, d.specific_gravity or 'None')
                    sheet.cell((v + 2), 15).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 16, d.hardness or 'None')
                    sheet.cell((v + 2), 16).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 17, d.variety or 'None')
                    sheet.cell((v + 2), 17).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 18, d.org or 'None')
                    sheet.cell((v + 2), 18).alignment = Alignment(wrap_text=True, vertical="center")
                    sheet.cell((v + 2), 19, d.remark or 'None')
                    sheet.cell((v + 2), 19).alignment = Alignment(wrap_text=True, vertical="center")
            var = save_virtual_workbook(workbook)
            workbook.close()
            response = HttpResponse(content=var,
                                    content_type='application/ms-excel')
            response['Content-Disposition'] = 'attachment; filename=certificate_record.xlsx'
            return response
        else:
            return redirect('error')
    except Exception as e:
        print(str(e))
        messages.error(request, str(e))
