from django.contrib import admin
from django.urls import include, path
from django.conf.urls import url
from django.conf.urls.static import static
from django.conf import settings
from blogsite import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r"^$", views.home, name='index'),
    url(r'^', include('accounts.urls')),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
