from django.shortcuts import render, redirect


def home(request):
    """ For home page"""
    return render(request, 'home.html')
